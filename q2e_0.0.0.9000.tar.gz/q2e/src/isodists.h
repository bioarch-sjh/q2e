

void iso(PEPTIDE *pep, int numpep, ISODIST  *dist);
