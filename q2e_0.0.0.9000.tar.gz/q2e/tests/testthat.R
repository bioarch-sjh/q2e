library(testthat)
library(q2e)

test_check("q2e")
