

context("test of original q2e functionality")
library(q2e)



test_that("q2e datafiles load correctly",{
  #messages don't appear to work!
  #message("Load test data file here")


})




test_that("q2e output file matches test data output file",{
  #messages don't appear to work!
  #message("Load test output")
  skip("Nowhere near this yet")

})
