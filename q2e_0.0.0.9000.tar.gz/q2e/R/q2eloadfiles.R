#' Create a structure that holds a list of files to be processed
#' 
#' @param filelistfile name of a file holding the list of files
#' @keywords q2e filelist
#' @export
#' @examples
#' q2eloadfiles()



q2eloadfiles <- function(filelistfile,verbose=F){

	#TODO: Type checking on set values:

	x <- read.table(filelistfile,fill=T)

	ndatafiles = as.integer(as.character(x[1,1]))
	nreplicates = as.integer(as.character(x[1,2]))

	if(ndatafiles != (nrow(x)-1)){
		message("ERROR:\n\tnumber of files specified is ",ndatafiles," but number of files listed is ", (nrow(x)-1) )
	}

	#TODO: Coerce this data into a form suitable for the C input.


	return(x)

}
