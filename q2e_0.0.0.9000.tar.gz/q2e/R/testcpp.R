
#' test the 'timesThree' cpp function
#'
#' @export
t3 <- function(x){
  return (timesThree(x))
}
